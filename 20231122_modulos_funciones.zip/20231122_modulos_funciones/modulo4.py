from simulacion4 import Silla

# Crear dos sillas
silla_azul = Silla(color="azul", precio=9.95)
silla_roja = Silla(color="roja", precio=9.95)

# Mostrar información de las sillas
print("Silla Azul - Color:", silla_azul.color, "- Precio:", silla_azul.precio)
print("Silla Roja - Color:", silla_roja.color, "- Precio:", silla_roja.precio)

