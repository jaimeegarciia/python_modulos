

class Mesa:
    def __init__(self, color, precio):
        self.color = color
        self.precio = precio

class Silla:
    def __init__(self, color, precio):
        self.color = color
        self.precio = precio

class Lampara:
    def __init__(self, color, precio):
        self.color = color
        self.precio = precio



