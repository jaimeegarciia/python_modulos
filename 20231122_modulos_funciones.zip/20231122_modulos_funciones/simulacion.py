#Actividad 1 - 25 puntos
#Por consola se piden como máximo 5 números hasta que pulsas q
#muestra la suma de los números introducidos.
#algoritmo funciona:5 puntos
#algoritmo utiliza mejora en argumentos : 5 puntos
#algoritmo controla errores y excepciones : 5 puntos
#algoritmo aplica funciones anónimas o recursividad : 5 puntos
#algoritmo resuelve una mejora de funcionalidad : 5 puntos

def main():
    numeros = []
    while True:
        entrada = input("Introduce un número o 'q' para salir: ")

        if entrada.lower() == 'q':
            break

        try:
            numero = float(entrada)
            numeros.append(numero)
            if len(numeros) >= 5:
                break
        except ValueError:
            print("introduce un número válido.")

    suma = sum(numeros)
    print(f"La suma es: {suma}")


if __name__ == "__main__":
    main()


