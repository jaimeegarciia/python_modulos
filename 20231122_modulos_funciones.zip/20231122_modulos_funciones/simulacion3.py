
numero_inicial = int(input("Ingrese el número inicial: "))


numero_final = int(input("Ingrese el número final: "))


if numero_inicial > numero_final:
    print("El número inicial debe ser menor que el número final. Inténtelo de nuevo.")
else:

    numeros_pares = [num for num in range(numero_inicial, numero_final + 1) if num % 2 == 0]


    print("Números pares entre {} y {}: {}".format(numero_inicial, numero_final, numeros_pares))
