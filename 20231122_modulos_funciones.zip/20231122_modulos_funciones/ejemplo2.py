#dos funciones que están en el ejemplo 2
#un módulo que puede contener class, variables y funciones
class Producto:
    def __init__(self,nombre,unidades):
        self.nombre=nombre
        self.unidades=unidades

alumnos={} #diccionario
asignaturas=[] #lista
calificaciones=() #tupla

def calcular_cuadrado():
    print("calcular cuadrado")
def calcular_cubo():
    print("calcular cubo")