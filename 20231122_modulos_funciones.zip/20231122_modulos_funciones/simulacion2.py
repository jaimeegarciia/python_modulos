import datetime


def calcular_factura(unidades, precio):
    subtotal = unidades * precio


    hoy = datetime.datetime.now()

    if hoy.day < 15:
        descuento = 0.05
        subtotal -= subtotal * descuento

    return subtotal


def main():
    try:
        unidades = int(input("Introduce la cantidad de unidades: "))
        precio = float(input("Introduce el precio por unidad: "))

        if unidades < 0 or precio < 0:
            raise ValueError("Las unidades y el precio deben ser números positivos.")

        total = calcular_factura(unidades, precio)
        print(f"El total de la factura es: {total:.2f} euros.")
    except ValueError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
